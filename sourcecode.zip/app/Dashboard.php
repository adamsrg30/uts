<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Dashboard extends Koneksi {

    public function totalHunian()
    {

        $sql = "SELECT COUNT(rmhID) as totalCount
				FROM tbl_rumah";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function totalWarga($gender)
    {

		if($gender == 1) {
			$sql = "SELECT COUNT(wargaID) as totalCount
					FROM tbl_warga
					WHERE penghuni <> 'tidak aktif' AND gender = 'pria'";
		} elseif($gender == 2) {
			$sql = "SELECT COUNT(wargaID) as totalCount
					FROM tbl_warga
					WHERE penghuni <> 'tidak aktif' AND gender = 'wanita'";
		} else {
			$sql = "SELECT COUNT(wargaID) as totalCount
					FROM tbl_warga
					WHERE penghuni <> 'tidak aktif'";
		}
		
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function totalPendapatan($month)
    {

		if($month == 0) {
			$sql = "SELECT SUM(amount) as totalCount 
					FROM tbl_iuran_payment";
		} else {
			$sql = "SELECT SUM(amount) as totalCount 
					FROM tbl_iuran_payment 
					WHERE MONTH(tglByr)=:month";
		}
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":month", $month);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }



}