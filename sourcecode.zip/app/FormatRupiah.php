<?php

namespace App;

class FormatRupiah {
    /**
     * Format the number to rupiah 
     * @param int $angka 
     * @return 
     */
    public static function formatRupiah($angka) {
        return "Rp "  . number_format($angka,2,',','.');
    }
}