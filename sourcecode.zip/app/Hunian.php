<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Hunian extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT * FROM tbl_rumah";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function lookup()
    {
        $sql = "SELECT * FROM tbl_rumah WHERE status <> 'kosong'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $nomorRmh = $_POST['nomorRmh'];
        $status = $_POST['status'];

        $sql = "INSERT INTO tbl_rumah (nomorRmh, status) VALUES (:nomorRmh, :status)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nomorRmh", $nomorRmh);
        $stmt->bindParam(":status", $status);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tbl_rumah WHERE rmhID=:rmhID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":rmhID", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $nomorRmh = $_POST['nomorRmh'];
        $status = $_POST['status'];
        $rmhID = $_POST['rmhID'];
		
        $sql = "UPDATE tbl_rumah SET nomorRmh=:nomorRmh, status=:status WHERE rmhID=:rmhID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nomorRmh", $nomorRmh);
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":rmhID", $rmhID);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tbl_rumah WHERE rmhID=:rmhID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":rmhID", $id);
        $stmt->execute();

    }

}