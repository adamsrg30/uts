<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Iuran extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT * FROM tbl_iuran_master";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function lookup()
    {
        $sql = "SELECT * FROM tbl_iuran_master WHERE active <> 'tidak aktif'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $namaIuran = $_POST['namaIuran'];
        $active = $_POST['active'];

        $sql = "INSERT INTO tbl_iuran_master (namaIuran, active) VALUES (:namaIuran, :active)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":namaIuran", $namaIuran);
        $stmt->bindParam(":active", $active);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tbl_iuran_master WHERE iuranID=:iuranID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":iuranID", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $namaIuran = $_POST['namaIuran'];
        $active = $_POST['active'];
        $iuranID = $_POST['iuranID'];
		
        $sql = "UPDATE tbl_iuran_master SET namaIuran=:namaIuran, active=:active WHERE iuranID=:iuranID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":namaIuran", $namaIuran);
        $stmt->bindParam(":active", $active);
        $stmt->bindParam(":iuranID", $iuranID);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tbl_iuran_master WHERE iuranID=:iuranID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":iuranID", $id);
        $stmt->execute();

    }

}