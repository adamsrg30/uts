<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Pembayaran extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT p.*, r.nomorRmh, i.namaIuran 
				FROM tbl_iuran_payment AS p 
				LEFT OUTER JOIN tbl_rumah AS r ON p.rmhID = r.rmhID 
				LEFT OUTER JOIN tbl_iuran_master AS i ON p.iuranID = i.iuranID 
				ORDER BY p.tglByr DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $rmhID = $_POST['rmhID'];
        $iuranID = $_POST['iuranID'];
        $amount = $_POST['amount'];
		if(strlen($_POST['dayTglBayar']) == 1) {
			$BayarDay = "0".$_POST['dayTglBayar'];
		} else {
			$BayarDay = $_POST['dayTglBayar'];
		}
		if(strlen($_POST['monthTglBayar']) == 1) {
			$BayarMonth = "0".$_POST['monthTglBayar'];
		} else {
			$BayarMonth = $_POST['monthTglBayar'];
		}
		$tglBayar = $_POST['yearTglBayar']."-".$BayarMonth."-".$BayarDay;
		
		echo "rmhID = ".$rmhID."<br>";
		echo "iuranID = ".$iuranID."<br>";
		echo "tglBayar = ".$tglBayar."<br>";
		echo "amount = ".$amount."<br>";
//		exit;

        $sql = "INSERT INTO tbl_iuran_payment (rmhID, iuranID, tglByr, amount) 
				VALUES (:rmhID, :iuranID, :tglByr, :amount)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":rmhID", $rmhID);
        $stmt->bindParam(":iuranID", $iuranID);
        $stmt->bindParam(":tglByr", $tglBayar);
        $stmt->bindParam(":amount", $amount);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT *, 
				DATE_FORMAT(tglByr, '%c') as monthTglBayar, 
				DATE_FORMAT(tglByr, '%e') as dayTglBayar, 
				DATE_FORMAT(tglByr, '%Y') as yearTglBayar 
				FROM tbl_iuran_payment 
				WHERE payID=:payID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":payID", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $rmhID = $_POST['rmhID'];
        $iuranID = $_POST['iuranID'];
        $amount = $_POST['amount'];
		if(strlen($_POST['dayTglBayar']) == 1) {
			$BayarDay = "0".$_POST['dayTglBayar'];
		} else {
			$BayarDay = $_POST['dayTglBayar'];
		}
		if(strlen($_POST['monthTglBayar']) == 1) {
			$BayarMonth = "0".$_POST['monthTglBayar'];
		} else {
			$BayarMonth = $_POST['monthTglBayar'];
		}
		$tglBayar = $_POST['yearTglBayar']."-".$BayarMonth."-".$BayarDay;
        $payID = $_POST['payID'];

        $sql = "UPDATE tbl_iuran_payment 
				SET rmhID=:rmhID, 
					iuranID=:iuranID, 
					tglByr=:tglByr, 
					amount=:amount 
				WHERE payID=:payID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":rmhID", $rmhID);
        $stmt->bindParam(":iuranID", $iuranID);
        $stmt->bindParam(":tglByr", $tglBayar);
        $stmt->bindParam(":amount", $amount);
        $stmt->bindParam(":payID", $payID);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tbl_iuran_payment WHERE payID=:payID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":payID", $id);
        $stmt->execute();

    }

}