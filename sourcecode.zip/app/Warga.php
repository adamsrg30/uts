<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Warga extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT w.*, r.nomorRmh FROM tbl_warga AS w LEFT OUTER JOIN tbl_rumah AS r ON w.rmhID = r.rmhID ORDER BY w.wargaID DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $namaWarga = $_POST['namaWarga'];
        $gender = $_POST['gender'];
        $noKTP = $_POST['noKTP'];
        $statusKeluarga = $_POST['statusKeluarga'];
        $penghuni = $_POST['penghuni'];
        $catatan = $_POST['catatan'];
        $rmhID = $_POST['rmhID'];

        $sql = "INSERT INTO tbl_warga (namaWarga, gender, noKTP, statusKeluarga, penghuni, catatan, rmhID) VALUES (:namaWarga, :gender, :noKTP, :statusKeluarga, :penghuni, :catatan, :rmhID)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":namaWarga", $namaWarga);
        $stmt->bindParam(":gender", $gender);
        $stmt->bindParam(":noKTP", $noKTP);
        $stmt->bindParam(":statusKeluarga", $statusKeluarga);
        $stmt->bindParam(":penghuni", $penghuni);
        $stmt->bindParam(":catatan", $catatan);
        $stmt->bindParam(":rmhID", $rmhID);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tbl_warga WHERE wargaID=:wargaID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":wargaID", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $namaWarga = $_POST['namaWarga'];
        $gender = $_POST['gender'];
        $noKTP = $_POST['noKTP'];
        $statusKeluarga = $_POST['statusKeluarga'];
        $penghuni = $_POST['penghuni'];
        $catatan = $_POST['catatan'];
        $rmhID = $_POST['rmhID'];
        $wargaID = $_POST['wargaID'];

        $sql = "UPDATE tbl_warga SET namaWarga=:namaWarga, gender=:gender, noKTP=:noKTP, statusKeluarga=:statusKeluarga, penghuni=:penghuni, catatan=:catatan, rmhID=:rmhID WHERE wargaID=:wargaID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":namaWarga", $namaWarga);
        $stmt->bindParam(":gender", $gender);
        $stmt->bindParam(":noKTP", $noKTP);
        $stmt->bindParam(":statusKeluarga", $statusKeluarga);
        $stmt->bindParam(":penghuni", $penghuni);
        $stmt->bindParam(":catatan", $catatan);
        $stmt->bindParam(":rmhID", $rmhID);
        $stmt->bindParam(":wargaID", $wargaID);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tbl_warga WHERE wargaID=:wargaID";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":wargaID", $id);
        $stmt->execute();

    }

}