-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 13, 2023 at 07:41 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugasweb`
--
CREATE DATABASE IF NOT EXISTS `tugasweb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `tugasweb`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_iuran_master`
--

DROP TABLE IF EXISTS `tbl_iuran_master`;
CREATE TABLE IF NOT EXISTS `tbl_iuran_master` (
  `iuranID` int(10) NOT NULL AUTO_INCREMENT,
  `namaIuran` varchar(255) DEFAULT NULL,
  `active` enum('aktif','tidak aktif') NOT NULL DEFAULT 'aktif',
  PRIMARY KEY (`iuranID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_iuran_master`
--

INSERT INTO `tbl_iuran_master` (`iuranID`, `namaIuran`, `active`) VALUES
(2, 'Keamanan', 'aktif'),
(3, 'Sampah', 'aktif'),
(4, 'Pemeliharaan Taman', 'tidak aktif');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_iuran_payment`
--

DROP TABLE IF EXISTS `tbl_iuran_payment`;
CREATE TABLE IF NOT EXISTS `tbl_iuran_payment` (
  `payID` bigint(100) NOT NULL AUTO_INCREMENT,
  `rmhID` int(10) NOT NULL DEFAULT '0',
  `iuranID` int(10) NOT NULL DEFAULT '0',
  `tglByr` date DEFAULT NULL,
  `amount` bigint(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`payID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_iuran_payment`
--

INSERT INTO `tbl_iuran_payment` (`payID`, `rmhID`, `iuranID`, `tglByr`, `amount`) VALUES
(3, 7, 2, '2023-01-12', 150000),
(4, 2, 3, '2023-05-01', 75000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rumah`
--

DROP TABLE IF EXISTS `tbl_rumah`;
CREATE TABLE IF NOT EXISTS `tbl_rumah` (
  `rmhID` int(10) NOT NULL AUTO_INCREMENT,
  `nomorRmh` varchar(25) DEFAULT NULL,
  `status` enum('pakai sendiri','dikontrakan','kosong') NOT NULL DEFAULT 'pakai sendiri',
  PRIMARY KEY (`rmhID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_rumah`
--

INSERT INTO `tbl_rumah` (`rmhID`, `nomorRmh`, `status`) VALUES
(2, 'Blok D6', 'pakai sendiri'),
(6, 'Blok D7B', 'kosong'),
(7, 'Blok D7A', 'dikontrakan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_warga`
--

DROP TABLE IF EXISTS `tbl_warga`;
CREATE TABLE IF NOT EXISTS `tbl_warga` (
  `wargaID` bigint(100) NOT NULL AUTO_INCREMENT,
  `namaWarga` varchar(255) DEFAULT NULL,
  `gender` enum('pria','wanita') DEFAULT NULL,
  `noKTP` varchar(255) NOT NULL DEFAULT '0',
  `statusKeluarga` enum('kepala keluarga','pasangan','anak','lainnya') DEFAULT NULL,
  `penghuni` enum('aktif','tidak aktif') NOT NULL DEFAULT 'aktif',
  `catatan` text,
  `rmhID` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`wargaID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_warga`
--

INSERT INTO `tbl_warga` (`wargaID`, `namaWarga`, `gender`, `noKTP`, `statusKeluarga`, `penghuni`, `catatan`, `rmhID`) VALUES
(3, 'Abraham', 'pria', '1234567890987654321', 'kepala keluarga', 'aktif', '', 7),
(5, 'Ayu Pertiwi Sudrajat', 'wanita', '45678765456', 'pasangan', 'aktif', '', 7);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
