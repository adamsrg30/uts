<?php

$id = $_GET['id'];

$hunian = new App\Hunian();
$rows = $hunian->delete($id);

?>

<div class="info">
      Data berhasil dihapus!
      <a href="index.php?hal=hunian_tampil">Kembali</a>
</div>