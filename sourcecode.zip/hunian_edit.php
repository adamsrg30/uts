<?php

$id = $_GET['id'];
$hunian = new App\Hunian();

$row = $hunian->edit($id);
?>
<h2>Edit Hunian</h2>

<form action="hunian_proses.php" method="post">
	<input type="hidden" name="rmhID" value="<?php echo $row['rmhID']; ?>">
 	<table>
		<tr>
            <td>Nomor Hunian</td>
            <td><input type="text" name="nomorRmh" value="<?php echo $row['nomorRmh']; ?>"></td>
        </tr>
        <tr>
            <td>Keterangan</td>
            <td>
				<select name="status">
					<option value="pakai sendiri"<?php echo (($row['status'] == 'pakai sendiri') ? " selected=\"selected\"" : ""); ?>>Pakai Sendiri</option>
					<option value="dikontrakan"<?php echo (($row['status'] == 'dikontrakan') ? " selected=\"selected\"" : ""); ?>>Dikontrakan</option>
					<option value="kosong"<?php echo (($row['status'] == 'kosong') ? " selected=\"selected\"" : ""); ?>>Kosong</option>
				</select>
			</td>
        </tr>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_update" value="SIMPAN">
				<input type="button" name="btn_balik" onClick="javascript:document.location.href='index.php?hal=hunian_tampil'" value="BATAL">
			</td>
        </tr>
    </table>
</form>