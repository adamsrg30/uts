<h2>Add Hunian</h2>

<form action="hunian_proses.php" method="post">
    <table>
        <tr>
            <td>Nomor Hunian</td>
            <td><input type="text" name="nomorRmh"></td>
        </tr>
        <tr>
            <td>Keterangan</td>
            <td>
				<select name="status">
					<option value="pakai sendiri">Pakai Sendiri</option>
					<option value="dikontrakan">Dikontrakan</option>
					<option value="kosong">Kosong</option>
				</select>
			</td>
        </tr>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_simpan" class="btn-inside" value="SIMPAN">
				<input type="button" name="btn_balik" class="btn-inside" onClick="javascript:document.location.href='index.php?hal=hunian_tampil'" value="BATAL">
			</td>
        </tr>
    </table>
</form>