<?php

require_once "inc/Koneksi.php";
require_once "app/Hunian.php";

$hunian = new App\Hunian();

if (isset($_POST['btn_simpan'])) {
    $hunian->simpan();
    header("location:index.php?hal=hunian_tampil");
}

if (isset($_POST['btn_update'])) {
    $hunian->update();
    header("location:index.php?hal=hunian_tampil");
}