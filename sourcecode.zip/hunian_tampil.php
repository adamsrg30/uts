<?php

$hunian = new App\Hunian();
$rows = $hunian->tampil();

?>

<h2>Hunian</h2>

<a href="index.php?hal=hunian_input" class="btn">Add Hunian</a>

<table>
    <tr>
        <th>NO</th>
        <th>NOMOR HUNIAN</th>
        <th>KETERANGAN</th>
        <th>AKSI</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['rmhID']; ?></td>
        <td><?php echo $row['nomorRmh']; ?></td>
        <td><?php echo ucfirst($row['status']); ?></td>
        <td><a href="index.php?hal=hunian_edit&id=<?php echo $row['rmhID']; ?>" class="btn">Edit</a>&nbsp;<a href="index.php?hal=hunian_delete&id=<?php echo $row['rmhID']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php } ?>
</table>
