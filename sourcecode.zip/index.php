<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Aplikasi Kewargaan by Adam Malik Siregar</title>

      <link rel="shortcut icon" href="layouts/assets/img/favicon.png" type="image/x-icon">
      <link rel="stylesheet" href="layouts/assets/css/style.css">
</head>

<body>

      <aside>

            <header>
                  <img src="layouts/assets/img/logo.png" class="brand">
                  <div class="user" style="color: #00F4CA;">APLIKASI<br>KEWARGAAN</div>
            </header>

            <nav>
                  <ul>
                        <li>
                              <a href="index.php">
                                    <img class="icon" src="layouts/assets/img/dashboard.png" alt=""> Dashboard
                              </a>
                        </li>
                        <li>
                              <a href="index.php?hal=hunian_tampil">
                                    <img class="icon" src="layouts/assets/img/hunian.png" alt=""> Hunian
                              </a>
                        </li>
                        <li>
                              <a href="index.php?hal=warga_tampil">
                                    <img class="icon" src="layouts/assets/img/warga.png" alt=""> Warga
                              </a>
                        </li>
                        <li>
                              <a href="index.php?hal=iuran_tampil">
                                    <img class="icon" src="layouts/assets/img/iuran.png" alt=""> Jenis Iuran
                              </a>
                        </li>
                        <li>
                              <a href="index.php?hal=pembayaran_tampil">
                                    <img class="icon" src="layouts/assets/img/payment.png" alt=""> Pembayaran
                              </a>
                        </li>
                  </ul>
            </nav>

      </aside>

      <main>
            <article>
                  <?php

                  require_once "vendor/autoload.php";
                  require_once "inc/Koneksi.php";

                  if (isset($_GET['hal'])) {
                        require $_GET['hal'] . ".php";
                  } else {
                        require "main.php";
                  }
                  ?>
            </article>

            <footer>
                  Copyright &copy; 2023. Designed by Mr. Sue - Modified by Adam Malik Siregar
            </footer>
      </main>

</body>

</html>