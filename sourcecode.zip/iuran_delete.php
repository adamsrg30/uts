<?php

$id = $_GET['id'];

$iuran = new App\Iuran();
$rows = $iuran->delete($id);

?>

<div class="info">
      Data berhasil dihapus!
      <a href="index.php?hal=iuran_tampil">Kembali</a>
</div>