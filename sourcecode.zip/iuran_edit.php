<?php

$id = $_GET['id'];
$iuran = new App\Iuran();

$row = $iuran->edit($id);
?>
<h2>Edit Jenis Iuran</h2>

<form action="iuran_proses.php" method="post">
	<input type="hidden" name="iuranID" value="<?php echo $row['iuranID']; ?>">
 	<table>
		<tr>
            <td>Nama Iuran</td>
            <td><input type="text" name="namaIuran" value="<?php echo $row['namaIuran']; ?>"></td>
        </tr>
        <tr>
            <td>Status</td>
            <td>
				<select name="active">
					<option value="aktif"<?php echo (($row['active'] == 'aktif') ? " selected=\"selected\"" : ""); ?>>Aktif</option>
					<option value="tidak aktif"<?php echo (($row['active'] == 'tidak aktif') ? " selected=\"selected\"" : ""); ?>>Tidak Aktif</option>
				</select>
			</td>
        </tr>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_update" value="SIMPAN">
				<input type="button" name="btn_balik" onClick="javascript:document.location.href='index.php?hal=iuran_tampil'" value="BATAL">
			</td>
        </tr>
    </table>
</form>