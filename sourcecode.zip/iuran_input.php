<h2>Add Jenis Iuran</h2>

<form action="iuran_proses.php" method="post">
    <table>
        <tr>
            <td>Nama Iuran</td>
            <td><input type="text" name="namaIuran"></td>
        </tr>
        <tr>
            <td>Status</td>
            <td>
				<select name="active">
					<option value="aktif">Aktif</option>
					<option value="tidak aktif">Tidak Aktif</option>
				</select>
			</td>
        </tr>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_simpan" value="SIMPAN">
				<input type="button" name="btn_balik" onClick="javascript:document.location.href='index.php?hal=iuran_tampil'" value="BATAL">
			</td>
        </tr>
    </table>
</form>