<?php

require_once "inc/Koneksi.php";
require_once "app/Iuran.php";

$iuran = new App\Iuran();

if (isset($_POST['btn_simpan'])) {
    $iuran->simpan();
    header("location:index.php?hal=iuran_tampil");
}

if (isset($_POST['btn_update'])) {
    $iuran->update();
    header("location:index.php?hal=iuran_tampil");
}