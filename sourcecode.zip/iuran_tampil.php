<?php

$iuran = new App\Iuran();
$rows = $iuran->tampil();

?>

<h2>Jenis Iuran</h2>

<a href="index.php?hal=iuran_input" class="btn">Add Jenis Iuran</a>

<table>
    <tr>
        <th>NO</th>
        <th>NAMA IURAN</th>
        <th>STATUS</th>
        <th>AKSI</th>
    </tr>
    <?php
	$no = 1;
	foreach ($rows as $row) {
	?>
    <tr>
        <td><?php echo $no; ?></td>
        <td><?php echo $row['namaIuran']; ?></td>
        <td><?php echo ucfirst($row['active']); ?></td>
        <td><a href="index.php?hal=iuran_edit&id=<?php echo $row['iuranID']; ?>" class="btn">Edit</a>&nbsp;<a href="index.php?hal=iuran_delete&id=<?php echo $row['iuranID']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php
		$no++;
	} 
	?>
</table>
