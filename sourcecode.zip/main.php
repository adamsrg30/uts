<?php
use Nim4n\SimpleDate;
use Nasution\Terbilang;

$dashboard = new App\Dashboard();
$formatRupiah = new App\FormatRupiah();
$totalHunian = $dashboard->totalHunian();
$totalWarga = $dashboard->totalWarga(0);
$totalWargaPria = $dashboard->totalWarga(1);
$totalWargaWanita = $dashboard->totalWarga(2);
$totalPendapatanBulanan = $dashboard->totalPendapatan(date("n"));
$totalPendapatan = $dashboard->totalPendapatan(0);

?>
<h2>Dashboard</h2>

<div class="info">Selamat datang, <strong>Adam Malik Siregar</strong></div>
<div style="margin: 26px; font-size: 18px;">
	<p>Jumlah Hunian : <strong><?php echo $totalHunian['totalCount']; ?></strong></p>
	<p>Jumlah Warga : <strong><?php echo $totalWarga['totalCount']; ?></strong><br>( <?php echo "<strong>".$totalWargaPria['totalCount']."</strong> Pria dan <strong>". $totalWargaWanita['totalCount']."</strong> Wanita"; ?> )</p>
	<p>Total Pendapatan (bulan ini) : <strong><br>
		<?php echo $formatRupiah->formatRupiah($totalPendapatanBulanan['totalCount']); ?></strong>
		( <em><?php echo ucwords(Terbilang::convert($totalPendapatanBulanan['totalCount'])." rupiah"); ?></em> )
	</p>
	<p>Total Pendapatan (semua) : <strong><br>
		<?php echo $formatRupiah->formatRupiah($totalPendapatan['totalCount']); ?></strong>
		( <em><?php echo ucwords(Terbilang::convert($totalPendapatan['totalCount'])." rupiah"); ?></em> )
	</p>
</div>