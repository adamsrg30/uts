<?php

$id = $_GET['id'];

$pembayaran = new App\Pembayaran();
$rows = $pembayaran->delete($id);

?>

<div class="info">
      Data berhasil dihapus!
      <a href="index.php?hal=pembayaran_tampil">Kembali</a>
</div>