<?php

$id = $_GET['id'];
$pembayaran = new App\Pembayaran();
$row = $pembayaran->edit($id);

$hunian = new App\Hunian();
$lookupHunian = $hunian->lookup();
$iuran = new App\Iuran();
$lookupIuran = $iuran->lookup();

function monthName($iMonthID) {
	if($iMonthID == 1) {
		$sMonthName = "Januari";	
	} elseif($iMonthID == 2) {
		$sMonthName = "Febuari";	
	} elseif($iMonthID == 3) {
		$sMonthName = "Maret";	
	} elseif($iMonthID == 4) {
		$sMonthName = "April";	
	} elseif($iMonthID == 5) {
		$sMonthName = "Mei";	
	} elseif($iMonthID == 6) {
		$sMonthName = "Juni";	
	} elseif($iMonthID == 7) {
		$sMonthName = "Juli";	
	} elseif($iMonthID == 8) {
		$sMonthName = "Agustus";	
	} elseif($iMonthID == 9) {
		$sMonthName = "September";	
	} elseif($iMonthID == 10) {
		$sMonthName = "Oktober";	
	} elseif($iMonthID == 11) {
		$sMonthName = "November";	
	} elseif($iMonthID == 12) {
		$sMonthName = "Desember";	
	}
	
	return $sMonthName;
}
?>
<h2>Add Pembayaran</h2>

<form action="pembayaran_proses.php" method="post">
	<input type="hidden" name="payID" value="<?php echo $row['payID']; ?>">
    <table>
        <tr>
            <td>Hunian</td>
            <td>
				<select name="rmhID">
					<option value="0">Pilih...</option>
				<?php
				if(!empty($lookupHunian)) {
					foreach($lookupHunian as $lH) {
				?>
					<option value="<?php echo $lH['rmhID']; ?>"<?php echo (($row['rmhID'] == $lH['rmhID']) ? " selected=\"selected\"" : ""); ?>><?php echo $lH['nomorRmh']; ?></option>
				<?php
					}
				}
				?>
				</select>
			</td>
        </tr>
        <tr>
            <td>Jenis Iuran</td>
            <td>
				<select name="iuranID">
					<option value="0">Pilih...</option>
				<?php
				if(!empty($lookupIuran)) {
					foreach($lookupIuran as $lI) {
				?>
					<option value="<?php echo $lI['iuranID']; ?>"<?php echo (($row['iuranID'] == $lI['iuranID']) ? " selected=\"selected\"" : ""); ?>><?php echo $lI['namaIuran']; ?></option>
				<?php
					}
				}
				?>
				</select>
			</td>
        </tr>
        <tr>
            <td>Tanggal Bayar</td>
            <td>
				<select name="dayTglBayar" data-width="75px">
				<?php
				$thisDay = date("j");
				for($iDay = 1; $iDay <= 31; $iDay++) {
				?>
					<option value="<?php echo $iDay; ?>"<?php echo (($row['dayTglBayar'] == $iDay) ? " selected=\"selected\"" : ""); ?>><?php echo $iDay; ?></option>
				<?php
				}
				?>
				</select>
				<select name="monthTglBayar" data-width="110px">
				<?php
				$thisMonth = date("n");
				for($iMonth = 1; $iMonth <= 12; $iMonth++) {
				?>
					<option value="<?php echo $iMonth; ?>"<?php echo (($row['monthTglBayar'] == $iMonth) ? " selected=\"selected\"" : ""); ?>><?php echo monthName($iMonth); ?></option>
				<?php
				}
				?>
				</select>
				<select name="yearTglBayar" data-width="90px">
				<?php
				$thisYear = date("Y");
				for($iYear = 2020; $iYear <= date("Y"); $iYear++) {
				?>
					<option value="<?php echo $iYear; ?>"<?php echo (($row['yearTglBayar'] == $iYear) ? " selected=\"selected\"" : ""); ?>><?php echo $iYear; ?></option>
				<?php
				}
				?>
				</select>
			</td>
        </tr>
        <tr>
            <td>Jumlah Bayar</td>
            <td><input type="text" name="amount" value="<?php echo $row['amount']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_update" value="SIMPAN">
				<input type="button" name="btn_balik" onClick="javascript:document.location.href='index.php?hal=pembayaran_tampil'" value="BATAL">
			</td>
        </tr>
    </table>
</form>