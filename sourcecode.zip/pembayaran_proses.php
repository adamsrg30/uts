<?php

require_once "inc/Koneksi.php";
require_once "app/Pembayaran.php";

$pembayaran = new App\Pembayaran();

if (isset($_POST['btn_simpan'])) {
    $pembayaran->simpan();
    header("location:index.php?hal=pembayaran_tampil");
}

if (isset($_POST['btn_update'])) {
    $pembayaran->update();
    header("location:index.php?hal=pembayaran_tampil");
}