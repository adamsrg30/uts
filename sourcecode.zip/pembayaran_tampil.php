<?php
use Nim4n\SimpleDate;
use Nasution\Terbilang;

$pembayaran = new App\Pembayaran();
$formatRupiah = new App\FormatRupiah();
$rows = $pembayaran->tampil();

?>

<h2>Pembayaran</h2>

<a href="index.php?hal=pembayaran_input" class="btn">Add Pembayaran</a>

<table>
    <tr>
        <th>NO</th>
        <th>HUNIAN</th>
        <th>JENIS IURAN</th>
        <th>TANGGAL BAYAR</th>
        <th>JUMLAH</th>
        <th>TERBILANG</th>
        <th>AKSI</th>
    </tr>
    <?php
	$no = 1;
	foreach ($rows as $row) {
		$txtTerbilang = Terbilang::convert($row['amount'])." rupiah";
	?>
    <tr>
        <td><?php echo $no; ?></td>
        <td><?php echo $row['nomorRmh']; ?></td>
        <td><?php echo ucfirst($row['namaIuran']); ?></td>
        <td><?php echo SimpleDate::dayDate($row['tglByr']); ?></td>
        <td style="text-align: right;"><?php echo $formatRupiah->formatRupiah($row['amount']); ?></td>
        <td><?php echo ucwords($txtTerbilang); ?></td>
        <td><a href="index.php?hal=pembayaran_edit&id=<?php echo $row['payID']; ?>" class="btn">Edit</a>&nbsp;<a href="index.php?hal=pembayaran_delete&id=<?php echo $row['payID']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php 
		$no++;	
	}
	?>
</table>
