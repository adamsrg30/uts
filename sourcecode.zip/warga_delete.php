<?php

$id = $_GET['id'];

$warga = new App\Warga();
$rows = $warga->delete($id);

?>

<div class="info">
      Data berhasil dihapus!
      <a href="index.php?hal=warga_tampil">Kembali</a>
</div>