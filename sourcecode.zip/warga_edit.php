<?php

$id = $_GET['id'];
$warga = new App\Warga();
$hunian = new App\Hunian();

$row = $warga->edit($id);
$lookupHunian = $hunian->lookup();

?>
<h2>Edit Warga</h2>

<form action="warga_proses.php" method="post">
	<input type="hidden" name="wargaID" value="<?php echo $row['wargaID']; ?>">
    <table>
        <tr>
            <td>Nama Warga</td>
            <td><input type="text" name="namaWarga" value="<?php echo $row['namaWarga']; ?>"></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>
				<select name="gender">
					<option value="pria"<?php echo (($row['gender'] == 'pria') ? " selected=\"selected\"" : ""); ?>>Pria</option>
					<option value="wanita"<?php echo (($row['gender'] == 'wanita') ? " selected=\"selected\"" : ""); ?>>Wanita</option>
				</select>
			</td>
        </tr>
        <tr>
            <td>No KTP</td>
            <td><input type="text" name="noKTP" value="<?php echo $row['noKTP']; ?>"></td>
        </tr>
        <tr>
            <td>Status Keluarga</td>
            <td>
				<select name="statusKeluarga">
					<option value="kepala keluarga"<?php echo (($row['statusKeluarga'] == 'kepala keluarga') ? " selected=\"selected\"" : ""); ?>>Kepala Keluarga</option>
					<option value="pasangan"<?php echo (($row['statusKeluarga'] == 'pasangan') ? " selected=\"selected\"" : ""); ?>>Pasangan</option>
					<option value="anak"<?php echo (($row['statusKeluarga'] == 'anak') ? " selected=\"selected\"" : ""); ?>>Anak</option>
					<option value="lainnya"<?php echo (($row['statusKeluarga'] == 'lainnya') ? " selected=\"selected\"" : ""); ?>>Lainnya</option>
				</select>
			</td>
        </tr>
        <tr>
            <td>Penghuni</td>
            <td>
				<select name="penghuni">
					<option value="aktif"<?php echo (($row['penghuni'] == 'aktif') ? " selected=\"selected\"" : ""); ?>>Ya</option>
					<option value="tidak aktif"<?php echo (($row['penghuni'] == 'tidak aktif') ? " selected=\"selected\"" : ""); ?>>Tidak</option>
				</select>
			</td>
        </tr>
        <tr>
            <td>Hunian</td>
            <td>
				<select name="rmhID" id="rmhID" class="selectpicker">
					<option value="0">Pilih...</option>
				<?php
				if(!empty($lookupHunian)) {
					foreach($lookupHunian as $lH) {
				?>
					<option value="<?php echo $lH['rmhID']; ?>"<?php echo (($row['rmhID'] == $lH['rmhID']) ? " selected=\"selected\"" : ""); ?>><?php echo $lH['nomorRmh']; ?></option>
				<?php
					}
				}
				?>
				</select>
			</td>
        </tr>
        <tr>
            <td>Catatan</td>
            <td><textarea name="catatan" id="" cols="30" rows="10"></textarea><?php echo $row['catatan']; ?></td>
        </tr>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_update" value="SIMPAN">
				<input type="button" name="btn_balik" onClick="javascript:document.location.href='index.php?hal=warga_tampil'" value="BATAL">
			</td>
        </tr>
    </table>
</form>