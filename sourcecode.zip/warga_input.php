<?php

$hunian = new App\Hunian();
$lookupHunian = $hunian->lookup();
?>
<h2>Add Warga</h2>

<form action="warga_proses.php" method="post">
    <table>
        <tr>
            <td>Nama Warga</td>
            <td><input type="text" name="namaWarga"></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>
				<select name="gender">
					<option value="pria">Pria</option>
					<option value="wanita">Wanita</option>
				</select>
			</td>
        </tr>
        <tr>
            <td>No KTP</td>
            <td><input type="text" name="noKTP"></td>
        </tr>
        <tr>
            <td>Status Keluarga</td>
            <td>
				<select name="statusKeluarga">
					<option value="kepala keluarga">Kepala Keluarga</option>
					<option value="pasangan">Pasangan</option>
					<option value="anak">Anak</option>
					<option value="lainnya">Lainnya</option>
				</select>
			</td>
        </tr>
        <tr>
            <td>Penghuni</td>
            <td>
				<select name="penghuni">
					<option value="aktif">Ya</option>
					<option value="tidak aktif">Tidak</option>
				</select>
			</td>
        </tr>
        <tr>
            <td>Hunian</td>
            <td>
				<select name="rmhID">
					<option value="0">Pilih...</option>
				<?php
				if(!empty($lookupHunian)) {
					foreach($lookupHunian as $lH) {
				?>
					<option value="<?php echo $lH['rmhID']; ?>"><?php echo $lH['nomorRmh']; ?></option>
				<?php
					}
				}
				?>
				</select>
			</td>
        </tr>
        <tr>
            <td>Catatan</td>
            <td><textarea name="catatan" id="" cols="30" rows="10"></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td>
				<input type="submit" name="btn_simpan" value="SIMPAN">
				<input type="button" name="btn_balik" onClick="javascript:document.location.href='index.php?hal=warga_tampil'" value="BATAL">
			</td>
        </tr>
    </table>
</form>