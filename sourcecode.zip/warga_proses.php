<?php

require_once "inc/Koneksi.php";
require_once "app/Warga.php";

$warga = new App\Warga();

if (isset($_POST['btn_simpan'])) {
    $warga->simpan();
    header("location:index.php?hal=warga_tampil");
}

if (isset($_POST['btn_update'])) {
    $warga->update();
    header("location:index.php?hal=warga_tampil");
}