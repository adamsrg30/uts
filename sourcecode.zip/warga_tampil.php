<?php

$warga = new App\Warga();
$rows = $warga->tampil();

?>

<h2>Warga</h2>

<a href="index.php?hal=warga_input" class="btn">Add Warga</a>

<table>
    <tr>
        <th>NO</th>
        <th>NAMA WARGA</th>
        <th>JENIS KELAMIN</th>
        <th>NO KTP</th>
        <th>STATUS KELUARGA</th>
        <th>PENGHUNI</th>
        <th>AKSI</th>
    </tr>
    <?php
	$no = 1;
	foreach ($rows as $row) {
		if($row['penghuni'] == "aktif") {
			$txtPenghuni = "Ya - ".$row['nomorRmh'];
		} else {
			$txtPenghuni = "Tidak";
		}
	?>
    <tr>
        <td><?php echo $no; ?></td>
        <td><?php echo ucfirst($row['namaWarga']); ?></td>
        <td><?php echo ucfirst($row['gender']); ?></td>
        <td><?php echo $row['noKTP']; ?></td>
        <td><?php echo ucfirst($row['statusKeluarga']); ?></td>
        <td><?php echo $txtPenghuni; ?></td>
        <td><a href="index.php?hal=warga_edit&id=<?php echo $row['wargaID']; ?>" class="btn">Edit</a>&nbsp;<a href="index.php?hal=warga_delete&id=<?php echo $row['wargaID']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php 
		$no++;	
	}
	?>
</table>
